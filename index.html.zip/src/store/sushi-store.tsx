import { createContext, useContext, useState, useCallback, useMemo, type ReactNode } from "react";
import { AREAS, DRIVERS, type MenuItem, type OrderStatus } from "@/data/sushi";

export type CartItem = MenuItem & { qty: number };

export type Order = {
  id: number;
  items: CartItem[];
  address: string;
  phone: string;
  payment: string;
  area: string;
  deliveryFee: number;
  eta: number;
  total: number;
  driver: { name: string; phone: string; avatar: string };
  status: OrderStatus;
  time: string;
};

type Lang = "en" | "ar";

type SushiContext = {
  lang: Lang;
  toggleLang: () => void;
  t: (en: string, ar: string) => string;
  cart: CartItem[];
  cartCount: number;
  cartOpen: boolean;
  setCartOpen: (v: boolean) => void;
  pulseCart: boolean;
  addToCart: (item: MenuItem) => void;
  removeFromCart: (id: number) => void;
  changeQty: (id: number, d: number) => void;
  clearCart: () => void;
  address: string;
  setAddress: (v: string) => void;
  phone: string;
  setPhone: (v: string) => void;
  payment: string;
  setPayment: (v: string) => void;
  area: typeof AREAS[number];
  subtotal: number;
  total: number;
  orderPlaced: Order | null;
  setOrderPlaced: (o: Order | null) => void;
  adminOrders: Order[];
  placeOrder: () => Order | null;
  updateOrderStatus: (id: number, status: OrderStatus) => void;
};

const Ctx = createContext<SushiContext | null>(null);

export function SushiProvider({ children }: { children: ReactNode }) {
  const [lang, setLang] = useState<Lang>("en");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [pulseCart, setPulseCart] = useState(false);
  const [address, setAddress] = useState("");
  const [phone, setPhone] = useState("");
  const [payment, setPayment] = useState("cash");
  const [orderPlaced, setOrderPlaced] = useState<Order | null>(null);
  const [adminOrders, setAdminOrders] = useState<Order[]>([]);

  const toggleLang = useCallback(() => setLang((l) => (l === "en" ? "ar" : "en")), []);
  const t = useCallback((en: string, ar: string) => (lang === "ar" ? ar : en), [lang]);

  const area = useMemo(() => {
    const a = address.toLowerCase();
    for (const ar of AREAS) if (ar.keywords.some((k) => a.includes(k))) return ar;
    return AREAS[3];
  }, [address]);

  const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const total = subtotal + (cart.length > 0 ? area.fee : 0);
  const cartCount = cart.reduce((s, i) => s + i.qty, 0);

  const addToCart = useCallback((item: MenuItem) => {
    setCart((c) => {
      const ex = c.find((x) => x.id === item.id);
      return ex ? c.map((x) => (x.id === item.id ? { ...x, qty: x.qty + 1 } : x)) : [...c, { ...item, qty: 1 }];
    });
    setPulseCart(true);
    setTimeout(() => setPulseCart(false), 500);
  }, []);

  const removeFromCart = useCallback((id: number) => setCart((c) => c.filter((x) => x.id !== id)), []);
  const changeQty = useCallback(
    (id: number, d: number) => setCart((c) => c.map((x) => (x.id === id ? { ...x, qty: Math.max(1, x.qty + d) } : x))),
    [],
  );
  const clearCart = useCallback(() => setCart([]), []);

  const placeOrder = useCallback((): Order | null => {
    if (!address || !phone || cart.length === 0) return null;
    const driver = DRIVERS[Math.floor(Math.random() * DRIVERS.length)];
    const order: Order = {
      id: Date.now(),
      items: [...cart],
      address,
      phone,
      payment,
      area: area.name,
      deliveryFee: area.fee,
      eta: area.eta,
      total,
      driver,
      status: "Preparing",
      time: new Date().toLocaleTimeString(),
    };
    setOrderPlaced(order);
    setAdminOrders((p) => [order, ...p]);
    setCart([]);
    return order;
  }, [address, phone, cart, payment, area, total]);

  const updateOrderStatus = useCallback((id: number, status: OrderStatus) => {
    setAdminOrders((p) => p.map((o) => (o.id === id ? { ...o, status } : o)));
    setOrderPlaced((o) => (o && o.id === id ? { ...o, status } : o));
  }, []);

  const value: SushiContext = {
    lang, toggleLang, t,
    cart, cartCount, cartOpen, setCartOpen, pulseCart,
    addToCart, removeFromCart, changeQty, clearCart,
    address, setAddress, phone, setPhone, payment, setPayment,
    area, subtotal, total,
    orderPlaced, setOrderPlaced, adminOrders, placeOrder, updateOrderStatus,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useSushi() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useSushi must be used within SushiProvider");
  return v;
}
