import { motion } from "framer-motion";
import { Plus, Flame } from "lucide-react";
import type { MenuItem } from "@/data/sushi";
import { useSushi } from "@/store/sushi-store";

/**
 * 3D tilt sushi card with photo, hot badge, sauces, and add button.
 */
export function SushiCard({ item, index = 0 }: { item: MenuItem; index?: number }) {
  const { addToCart, t, lang } = useSushi();

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5, delay: index * 0.05 }}
      whileHover={{ y: -8 }}
      className="group perspective-1000 relative"
    >
      <div className="preserve-3d relative overflow-hidden rounded-3xl border border-border bg-card shadow-card transition-all duration-500 group-hover:shadow-elevated group-hover:[transform:rotateX(4deg)_rotateY(-4deg)]">
        {/* photo */}
        <div className="relative h-56 overflow-hidden">
          <img
            src={item.img}
            alt={item.name}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-card via-card/30 to-transparent" />

          {item.hot && (
            <div className="absolute left-3 top-3 flex items-center gap-1 rounded-full bg-primary/95 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-primary-foreground shadow-lg backdrop-blur">
              <Flame className="h-3 w-3" />
              Hot
            </div>
          )}

          <div
            className="absolute right-3 top-3 grid h-10 w-10 place-items-center rounded-full text-lg shadow-lg backdrop-blur"
            style={{ background: `${item.color} / 30%`, backgroundColor: "oklch(from var(--card) l c h / 0.7)" }}
          >
            {item.emoji}
          </div>

          <div className="absolute bottom-3 left-4 right-4">
            <div className="font-display text-xl font-bold leading-tight text-foreground drop-shadow-lg">
              {lang === "ar" ? item.name_ar : item.name}
            </div>
          </div>
        </div>

        {/* body */}
        <div className="p-5">
          <p className="mb-3 line-clamp-2 text-sm text-muted-foreground">
            {lang === "ar" ? item.desc_ar : item.desc}
          </p>
          <div className="mb-4 flex flex-wrap gap-1.5">
            {item.sauces.map((s) => (
              <span
                key={s}
                className="rounded-full border border-border bg-muted/50 px-2.5 py-0.5 text-[10px] font-medium text-muted-foreground"
              >
                🥢 {s}
              </span>
            ))}
          </div>
          <div className="flex items-center justify-between">
            <div className="font-display text-2xl font-bold tabular-nums" style={{ color: item.color }}>
              {item.price}
              <span className="ml-1 text-xs font-normal text-muted-foreground">EGP</span>
            </div>
            <motion.button
              whileTap={{ scale: 0.9 }}
              onClick={() => addToCart(item)}
              className="shine flex items-center gap-1.5 rounded-full bg-gradient-to-r from-primary to-primary-glow px-4 py-2 text-xs font-semibold text-primary-foreground shadow-[0_8px_25px_-8px_var(--primary)]"
            >
              <Plus className="h-3.5 w-3.5" />
              {t("Add", "أضف")}
            </motion.button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
