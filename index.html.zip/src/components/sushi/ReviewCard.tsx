import { useState } from "react";
import { motion } from "framer-motion";
import { Heart, Star } from "lucide-react";

type Review = {
  id: number; name: string; avatar: string; stars: number;
  time: string; text: string; en: string; likes: number;
};

export function ReviewCard({ r }: { r: Review }) {
  const [liked, setLiked] = useState(false);
  const [likes, setLikes] = useState(r.likes);
  const [showEn, setShowEn] = useState(false);

  return (
    <motion.div
      whileHover={{ y: -4 }}
      className="relative w-72 flex-shrink-0 overflow-hidden rounded-3xl border border-border bg-card/60 p-5 backdrop-blur"
    >
      <div className="absolute inset-x-0 top-0 h-[3px] bg-gradient-to-r from-primary via-gold to-primary" />
      <div className="mb-3 flex items-center gap-3">
        <div className="grid h-10 w-10 place-items-center rounded-full bg-primary/15 text-sm font-bold text-primary ring-2 ring-primary/30">
          {r.avatar}
        </div>
        <div className="min-w-0 flex-1">
          <div className="truncate text-sm font-semibold">{r.name}</div>
          <div className="flex items-center gap-1.5">
            <div className="flex">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className={`h-3 w-3 ${i < r.stars ? "fill-gold text-gold" : "text-muted"}`} />
              ))}
            </div>
            <span className="text-[10px] text-muted-foreground">{r.time}</span>
          </div>
        </div>
      </div>
      <p
        onClick={() => setShowEn((v) => !v)}
        className="mb-3 cursor-pointer text-sm leading-relaxed text-foreground/90"
      >
        {showEn ? r.en : r.text}
        <span className="ml-2 text-[10px] text-muted-foreground">
          {showEn ? "🇪🇬 ar" : "🇬🇧 en"}
        </span>
      </p>
      <button
        onClick={() => {
          setLiked((v) => !v);
          setLikes((l) => (liked ? l - 1 : l + 1));
        }}
        className="flex items-center gap-1.5 text-xs text-muted-foreground transition hover:text-primary"
      >
        <Heart className={`h-3.5 w-3.5 transition ${liked ? "fill-primary text-primary" : ""}`} />
        {likes}
      </button>
    </motion.div>
  );
}
