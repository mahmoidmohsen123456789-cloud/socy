import { Link, useLocation } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ShoppingBag, Globe, Menu as MenuIcon, X } from "lucide-react";
import { useState, useEffect } from "react";
import { useSushi } from "@/store/sushi-store";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", labelEn: "Home", labelAr: "الرئيسية" },
  { to: "/menu", labelEn: "Menu", labelAr: "القائمة" },
  { to: "/order", labelEn: "Order", labelAr: "اطلب" },
  { to: "/tracking", labelEn: "Tracking", labelAr: "التتبع" },
  { to: "/about", labelEn: "About", labelAr: "عن المطعم" },
] as const;

export function NavBar() {
  const { t, lang, toggleLang, cartCount, setCartOpen, pulseCart } = useSushi();
  const location = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "sticky top-0 z-50 w-full transition-all duration-500",
        scrolled ? "glass-strong shadow-card" : "bg-transparent",
      )}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3 md:px-8 md:py-4">
        <Link to="/" className="group flex items-center gap-3">
          <motion.div
            whileHover={{ rotate: 360, scale: 1.1 }}
            transition={{ duration: 0.6 }}
            className="relative grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-primary to-primary-glow text-xl shadow-[0_0_30px_-5px_var(--primary)]"
          >
            🍣
          </motion.div>
          <div className="leading-tight">
            <div className="font-display text-lg font-bold tracking-[0.2em] text-foreground md:text-xl">
              SUSHI <span className="text-gradient-primary">CIRCLE</span>
            </div>
            <div className="text-[9px] font-medium tracking-[0.35em] text-muted-foreground">
              {t("MADINATY · NEW CAIRO", "مدينتي · القاهرة الجديدة")}
            </div>
          </div>
        </Link>

        <nav className="hidden items-center gap-1 lg:flex">
          {NAV.map((n) => {
            const active = location.pathname === n.to;
            return (
              <Link
                key={n.to}
                to={n.to}
                className={cn(
                  "relative rounded-full px-4 py-2 text-xs font-medium uppercase tracking-widest transition-colors",
                  active ? "text-foreground" : "text-muted-foreground hover:text-foreground",
                )}
              >
                {active && (
                  <motion.span
                    layoutId="nav-active"
                    className="absolute inset-0 -z-0 rounded-full bg-primary/15 ring-1 ring-primary/40"
                    transition={{ type: "spring", stiffness: 400, damping: 30 }}
                  />
                )}
                <span className="relative z-10">{lang === "ar" ? n.labelAr : n.labelEn}</span>
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleLang}
            className="hidden h-9 items-center gap-1.5 rounded-full border border-border bg-card/40 px-3 text-xs font-medium text-muted-foreground transition hover:text-foreground sm:flex"
            aria-label="Toggle language"
          >
            <Globe className="h-3.5 w-3.5" />
            {lang === "en" ? "عربي" : "EN"}
          </button>

          <motion.button
            onClick={() => setCartOpen(true)}
            animate={pulseCart ? { scale: [1, 1.2, 1] } : {}}
            transition={{ duration: 0.4 }}
            className="relative flex h-9 items-center gap-2 rounded-full bg-gradient-to-r from-primary to-primary-glow px-4 text-xs font-semibold text-primary-foreground shadow-[0_8px_30px_-8px_var(--primary)] transition hover:brightness-110"
          >
            <ShoppingBag className="h-4 w-4" />
            <span>{t("Cart", "السلة")}</span>
            {cartCount > 0 && (
              <span className="grid h-5 min-w-5 place-items-center rounded-full bg-background/30 px-1.5 text-[10px] font-bold tabular-nums">
                {cartCount}
              </span>
            )}
          </motion.button>

          <button
            onClick={() => setOpen((v) => !v)}
            className="grid h-9 w-9 place-items-center rounded-full border border-border text-muted-foreground lg:hidden"
            aria-label="Menu"
          >
            {open ? <X className="h-4 w-4" /> : <MenuIcon className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {open && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: "auto", opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          className="glass-strong overflow-hidden lg:hidden"
        >
          <div className="flex flex-col gap-1 px-4 py-3">
            {NAV.map((n) => {
              const active = location.pathname === n.to;
              return (
                <Link
                  key={n.to}
                  to={n.to}
                  onClick={() => setOpen(false)}
                  className={cn(
                    "rounded-lg px-3 py-2.5 text-sm font-medium transition",
                    active ? "bg-primary/15 text-foreground" : "text-muted-foreground hover:bg-muted",
                  )}
                >
                  {lang === "ar" ? n.labelAr : n.labelEn}
                </Link>
              );
            })}
            <button
              onClick={() => {
                toggleLang();
                setOpen(false);
              }}
              className="mt-1 flex items-center gap-2 rounded-lg px-3 py-2.5 text-sm text-muted-foreground"
            >
              <Globe className="h-4 w-4" />
              {lang === "en" ? "عربي" : "English"}
            </button>
          </div>
        </motion.div>
      )}
    </header>
  );
}
