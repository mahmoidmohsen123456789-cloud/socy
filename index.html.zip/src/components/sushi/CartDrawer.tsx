import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "@tanstack/react-router";
import { X, Plus, Minus, Trash2, ShoppingBag } from "lucide-react";
import { useSushi } from "@/store/sushi-store";

export function CartDrawer() {
  const {
    cart, cartOpen, setCartOpen, removeFromCart, changeQty,
    address, area, total, t,
  } = useSushi();
  const navigate = useNavigate();

  return (
    <AnimatePresence>
      {cartOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[200] bg-black/60 backdrop-blur-sm"
            onClick={() => setCartOpen(false)}
          />
          <motion.aside
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 300, damping: 32 }}
            className="glass-strong fixed inset-y-0 right-0 z-[201] flex w-full max-w-sm flex-col overflow-y-auto border-l border-border p-6"
          >
            <div className="mb-6 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShoppingBag className="h-5 w-5 text-primary" />
                <h3 className="font-display text-lg font-semibold">
                  {t("Your Cart", "سلتك")}
                </h3>
              </div>
              <button
                onClick={() => setCartOpen(false)}
                className="grid h-8 w-8 place-items-center rounded-full text-muted-foreground hover:bg-muted hover:text-foreground"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            {cart.length === 0 ? (
              <div className="flex flex-1 flex-col items-center justify-center text-center">
                <div className="mb-4 grid h-20 w-20 place-items-center rounded-full bg-muted text-3xl">
                  🍣
                </div>
                <p className="text-sm text-muted-foreground">
                  {t("Your cart is empty", "السلة فارغة")}
                </p>
                <button
                  onClick={() => {
                    setCartOpen(false);
                    navigate({ to: "/menu" });
                  }}
                  className="mt-5 rounded-full bg-primary px-5 py-2 text-xs font-semibold text-primary-foreground"
                >
                  {t("Browse Menu", "تصفح القائمة")}
                </button>
              </div>
            ) : (
              <>
                <div className="flex-1 space-y-3">
                  {cart.map((item) => (
                    <motion.div
                      key={item.id}
                      layout
                      initial={{ opacity: 0, x: 30 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: 30 }}
                      className="flex gap-3 rounded-2xl border border-border bg-card/40 p-3"
                    >
                      <img
                        src={item.img}
                        alt={item.name}
                        loading="lazy"
                        className="h-16 w-16 flex-shrink-0 rounded-xl object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <div className="truncate text-sm font-semibold">{item.name}</div>
                            <div className="text-[11px] text-muted-foreground">
                              {item.price} EGP
                            </div>
                          </div>
                          <button
                            onClick={() => removeFromCart(item.id)}
                            className="text-muted-foreground transition hover:text-destructive"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                        <div className="mt-2 flex items-center gap-2">
                          <button
                            onClick={() => changeQty(item.id, -1)}
                            className="grid h-6 w-6 place-items-center rounded-md bg-muted text-foreground"
                          >
                            <Minus className="h-3 w-3" />
                          </button>
                          <span className="min-w-5 text-center text-sm font-semibold tabular-nums">
                            {item.qty}
                          </span>
                          <button
                            onClick={() => changeQty(item.id, 1)}
                            className="grid h-6 w-6 place-items-center rounded-md bg-muted text-foreground"
                          >
                            <Plus className="h-3 w-3" />
                          </button>
                          <span className="ml-auto text-sm font-bold text-primary">
                            {item.price * item.qty} EGP
                          </span>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="mt-4 border-t border-border pt-4">
                  {address && (
                    <div className="mb-2 flex items-center justify-between text-xs text-muted-foreground">
                      <span>🚚 {area.name}</span>
                      <span>
                        {area.fee} EGP · {area.eta} min
                      </span>
                    </div>
                  )}
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-muted-foreground">
                      {t("Total", "الإجمالي")}
                    </span>
                    <span className="font-display text-2xl font-bold text-primary">
                      {total} <span className="text-sm">EGP</span>
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      setCartOpen(false);
                      navigate({ to: "/order" });
                    }}
                    className="shine mt-4 w-full rounded-full bg-gradient-to-r from-primary to-primary-glow py-3.5 text-sm font-semibold text-primary-foreground shadow-[0_10px_30px_-10px_var(--primary)] transition hover:brightness-110"
                  >
                    {t("Proceed to Checkout →", "إتمام الطلب →")}
                  </button>
                </div>
              </>
            )}
          </motion.aside>
        </>
      )}
    </AnimatePresence>
  );
}
