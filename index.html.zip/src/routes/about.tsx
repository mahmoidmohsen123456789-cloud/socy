import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { MapPin, Phone, Clock, Award, Leaf, Heart } from "lucide-react";
import { PHOTOS } from "@/data/sushi";
import { useSushi } from "@/store/sushi-store";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Sushi Circle · Our Story" },
      { name: "description", content: "Meet Sushi Circle: a passion project bringing Edo-style sushi craft to Madinaty Central Park. Family-run, fresh daily, made with love." },
      { property: "og:title", content: "About Sushi Circle" },
      { property: "og:description", content: "Edo-style craft. Cairo soul. Family-run since day one." },
      { property: "og:image", content: PHOTOS.chef },
      { name: "twitter:image", content: PHOTOS.chef },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  const { t } = useSushi();
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0">
          <img src={PHOTOS.chef} alt="" className="h-full w-full object-cover opacity-30" />
          <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-background/85 to-background" />
        </div>
        <div className="relative mx-auto max-w-4xl px-6 py-24 text-center md:py-32">
          <span className="text-xs font-semibold uppercase tracking-[0.4em] text-primary">
            {t("Our Story", "قصتنا")}
          </span>
          <h1 className="mt-3 font-display text-5xl font-bold md:text-7xl">
            {t("Edo Craft. ", "حرفة إيدو. ")}
            <span className="text-gradient-gold">{t("Cairo Soul.", "روح القاهرة.")}</span>
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
            {t(
              "Sushi Circle began with a simple obsession: a sauce that wouldn't leave our heads. From a tiny Madinaty kitchen, it grew into a Central Park destination — and a Cairo cult favorite.",
              "بدأت قصة سوشي سيركل من إدمان واحد: صوص ما عرفناش ننساه. من مطبخ صغير في مدينتي، كبر وبقى وجهة في السنترال بارك — وحب القاهرة كلها.",
            )}
          </p>
        </div>
      </section>

      {/* Pillars */}
      <section className="mx-auto max-w-6xl px-6 py-20">
        <div className="grid gap-6 md:grid-cols-3">
          {[
            { icon: Leaf, t: t("Fresh Daily", "طازج يوميًا"), d: t("Fish flown in, prepped each morning. Nothing sits.", "أسماك تصل وتُحضّر كل صباح. لا شيء ينتظر.") },
            { icon: Award, t: t("Edo-Trained Chefs", "شيفات على تقاليد إيدو"), d: t("Years apprenticing under masters. Every cut intentional.", "سنوات من التدريب على يد الأساتذة. كل قطعة بنية.") },
            { icon: Heart, t: t("Made with Love", "مصنوع بحب"), d: t("Family-run. Same hands. Same standards. Every plate.", "عائلي. نفس الأيدي. نفس المعايير. كل طبق.") },
          ].map((p, i) => (
            <motion.div
              key={p.t}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="rounded-3xl border border-border bg-card/40 p-8"
            >
              <div className="mb-4 grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-primary to-primary-glow text-primary-foreground shadow-[0_10px_30px_-10px_var(--primary)]">
                <p.icon className="h-6 w-6" />
              </div>
              <h3 className="mb-2 font-display text-xl font-bold">{p.t}</h3>
              <p className="text-sm text-muted-foreground">{p.d}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Gallery */}
      <section className="mx-auto max-w-7xl px-6 py-12">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {[PHOTOS.ambience, PHOTOS.chef, PHOTOS.sauce, PHOTOS.platter, PHOTOS.salmon, PHOTOS.roll1, PHOTOS.nigiri, PHOTOS.roll2].map((p, i) => (
            <motion.img
              key={i}
              src={p}
              alt=""
              loading="lazy"
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="aspect-square w-full rounded-3xl object-cover transition hover:scale-105"
            />
          ))}
        </div>
      </section>

      {/* Visit */}
      <section className="mx-auto max-w-4xl px-6 py-20">
        <div className="rounded-3xl border border-border bg-card/40 p-8 md:p-12">
          <h2 className="font-display text-3xl font-bold md:text-4xl">{t("Come Sit With Us", "تعالى اقعد معانا")}</h2>
          <div className="mt-6 grid gap-5 md:grid-cols-3">
            <div className="flex items-start gap-3">
              <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
              <div>
                <div className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">{t("Find Us", "موقعنا")}</div>
                <div className="mt-1 font-medium">{t("Madinaty Central Park", "سنترال بارك مدينتي")}</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Clock className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
              <div>
                <div className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">{t("Hours", "المواعيد")}</div>
                <div className="mt-1 font-medium">{t("Daily 12 PM – 12 AM", "يوميًا ١٢ ظهراً – ١٢ منتصف الليل")}</div>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <Phone className="mt-0.5 h-5 w-5 shrink-0 text-primary" />
              <div>
                <div className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">{t("Reserve", "احجز")}</div>
                <a href="tel:01007726633" className="mt-1 block font-medium hover:text-primary">01007726633</a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
