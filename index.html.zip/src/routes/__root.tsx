import { Outlet, createRootRoute, HeadContent, Scripts, Link } from "@tanstack/react-router";
import appCss from "../styles.css?url";
import { SushiProvider, useSushi } from "@/store/sushi-store";
import { NavBar } from "@/components/sushi/NavBar";
import { CartDrawer } from "@/components/sushi/CartDrawer";
import { Footer } from "@/components/sushi/Footer";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <div className="mb-4 text-7xl">🍣</div>
        <h1 className="font-display text-7xl font-bold text-gradient-primary">404</h1>
        <h2 className="mt-4 font-display text-xl font-semibold">Lost in the rice paddy</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          This page rolled away. Let's get you back to the sushi.
        </p>
        <Link
          to="/"
          className="mt-6 inline-flex items-center justify-center rounded-full bg-gradient-to-r from-primary to-primary-glow px-6 py-2.5 text-sm font-semibold text-primary-foreground shadow-[0_8px_30px_-8px_var(--primary)]"
        >
          Take me home
        </Link>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Sushi Circle — Premium Japanese in Madinaty & New Cairo" },
      { name: "description", content: "Sushi Circle: bold, fresh, viral Japanese sushi at Madinaty Central Park. Order online with fast delivery across New Cairo." },
      { name: "author", content: "Sushi Circle" },
      { property: "og:title", content: "Sushi Circle — Premium Japanese Sushi" },
      { property: "og:description", content: "Bold, fresh, viral. The sauce that changed everything 🔥" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:site", content: "@SushiCircle" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;600;700;800;900&family=Inter:wght@400;500;600;700&family=Noto+Serif+JP:wght@500;700&family=Cairo:wght@400;600;700&display=swap" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <head>
        <HeadContent />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function LayoutInner() {
  const { lang } = useSushi();
  return (
    <div dir={lang === "ar" ? "rtl" : "ltr"} className="flex min-h-screen flex-col">
      <NavBar />
      <CartDrawer />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
    </div>
  );
}

function RootComponent() {
  return (
    <SushiProvider>
      <LayoutInner />
    </SushiProvider>
  );
}
