import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useSushi } from "@/store/sushi-store";
import { STATUSES, STATUS_COLORS } from "@/data/sushi";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Admin — Sushi Circle Dashboard" },
      { name: "robots", content: "noindex,nofollow" },
    ],
  }),
  component: AdminPage,
});

function AdminPage() {
  const { adminOrders, updateOrderStatus } = useSushi();
  const [pin, setPin] = useState("");
  const [auth, setAuth] = useState(false);

  if (!auth) {
    return (
      <div className="mx-auto flex min-h-[70vh] max-w-sm items-center px-6">
        <div className="w-full rounded-3xl border border-border bg-card/40 p-8 text-center">
          <div className="text-4xl">⚙️</div>
          <h2 className="mt-3 font-display text-xl font-bold">Admin Dashboard</h2>
          <p className="text-xs text-muted-foreground">Sushi Circle · Staff Only</p>
          <input
            type="password"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            placeholder="PIN (try: 1234)"
            className="mt-5 w-full rounded-xl border border-input bg-background/50 px-4 py-3 text-sm outline-none focus:border-primary"
          />
          <button
            onClick={() => pin === "1234" && setAuth(true)}
            className="mt-3 w-full rounded-full bg-gradient-to-r from-primary to-primary-glow px-4 py-3 text-sm font-semibold text-primary-foreground"
          >
            Login
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-6 py-10">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="font-display text-2xl font-bold md:text-3xl">⚙️ Restaurant Dashboard</h1>
        <button
          onClick={() => setAuth(false)}
          className="rounded-full border border-border px-4 py-1.5 text-xs text-muted-foreground"
        >
          Logout
        </button>
      </div>

      <div className="mb-8 grid grid-cols-3 gap-4">
        {[
          ["Total Orders", adminOrders.length, "📦"],
          ["Preparing", adminOrders.filter((o) => o.status === "Preparing").length, "👨‍🍳"],
          ["Delivered", adminOrders.filter((o) => o.status === "Delivered").length, "✅"],
        ].map(([l, v, i]) => (
          <div key={l as string} className="rounded-2xl border border-border bg-card/40 p-5 text-center">
            <div className="text-2xl">{i}</div>
            <div className="font-display text-3xl font-bold text-gradient-primary">{v}</div>
            <div className="text-xs uppercase tracking-widest text-muted-foreground">{l}</div>
          </div>
        ))}
      </div>

      {adminOrders.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-border bg-card/20 py-16 text-center text-muted-foreground">
          No orders yet
        </div>
      ) : (
        <div className="space-y-3">
          {adminOrders.map((o) => (
            <div key={o.id} className="rounded-2xl border border-border bg-card/40 p-5">
              <div className="mb-3 flex items-center justify-between">
                <div>
                  <span className="font-semibold">Order #{String(o.id).slice(-4)}</span>
                  <span className="ml-3 text-xs text-muted-foreground">{o.time}</span>
                </div>
                <span
                  className="rounded-full px-3 py-1 text-xs font-semibold"
                  style={{ background: `${STATUS_COLORS[o.status]}20`, color: STATUS_COLORS[o.status] }}
                >
                  {o.status}
                </span>
              </div>
              <div className="mb-3 flex flex-wrap gap-2">
                {o.items.map((i) => (
                  <div key={i.id} className="relative">
                    <img src={i.img} alt={i.name} className="h-10 w-10 rounded-lg object-cover ring-1 ring-border" />
                    <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-primary px-1 text-[9px] font-bold text-primary-foreground">
                      {i.qty}
                    </span>
                  </div>
                ))}
              </div>
              <div className="mb-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                <span>📍 {o.address}</span>
                <span>📞 {o.phone}</span>
                <span>💰 {o.total} EGP</span>
                <span>💵 {o.payment}</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {STATUSES.filter((s) => s !== o.status).map((s) => (
                  <button
                    key={s}
                    onClick={() => updateOrderStatus(o.id, s)}
                    className="rounded-full border border-border bg-card px-3 py-1.5 text-xs hover:border-primary hover:text-primary"
                  >
                    → {s}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
