import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Phone, MapPin, CreditCard, Wallet, MessageCircle, Smartphone } from "lucide-react";
import { useSushi } from "@/store/sushi-store";
import { PHOTOS } from "@/data/sushi";

export const Route = createFileRoute("/order")({
  head: () => ({
    meta: [
      { title: "Order Online — Sushi Circle · Madinaty & New Cairo Delivery" },
      { name: "description", content: "Place your Sushi Circle order online. Cash, card, InstaPay or WhatsApp. Fast delivery across Madinaty, New Cairo and Nasr City." },
      { property: "og:title", content: "Order Sushi Circle Online" },
      { property: "og:description", content: "Hot, fresh, on your door in 30 minutes." },
    ],
  }),
  component: OrderPage,
});

const PAYMENTS = [
  { id: "cash", icon: Wallet, labelEn: "Cash on Delivery", labelAr: "كاش عند الاستلام" },
  { id: "whatsapp", icon: MessageCircle, labelEn: "WhatsApp", labelAr: "واتساب" },
  { id: "instapay", icon: Smartphone, labelEn: "InstaPay", labelAr: "إنستاباي" },
  { id: "card", icon: CreditCard, labelEn: "Card", labelAr: "بطاقة" },
] as const;

function OrderPage() {
  const {
    t, lang, cart, address, setAddress, phone, setPhone,
    payment, setPayment, area, subtotal, total, placeOrder,
  } = useSushi();
  const navigate = useNavigate();

  function handlePlace() {
    const o = placeOrder();
    if (o) navigate({ to: "/tracking" });
  }

  function handleWhatsapp() {
    if (!address || !phone || cart.length === 0) return;
    const lines = cart.map((i, idx) => `${idx + 1}. ${i.name} ×${i.qty} — ${i.price * i.qty} EGP`).join("\n");
    const msg = `🍣 *Sushi Circle Order*\n\n${lines}\n\n📍 Address: ${address}\n📞 Phone: ${phone}\n🚚 Delivery: ${area.fee} EGP (${area.name})\n⏱ ETA: ${area.eta} mins\n💰 Total: ${total} EGP\n💵 Payment: ${payment}`;
    window.open(`https://wa.me/201007726633?text=${encodeURIComponent(msg)}`, "_blank");
  }

  if (cart.length === 0) {
    return (
      <div className="mx-auto flex min-h-[70vh] max-w-md flex-col items-center justify-center px-6 text-center">
        <img src={PHOTOS.platter} alt="" className="mb-6 h-40 w-56 rounded-3xl object-cover opacity-60" />
        <h2 className="font-display text-3xl font-bold">{t("Your cart is empty", "السلة فارغة")}</h2>
        <p className="mt-2 text-muted-foreground">{t("Let's fix that.", "خليني أساعدك.")}</p>
        <Link
          to="/menu"
          className="mt-6 rounded-full bg-gradient-to-r from-primary to-primary-glow px-8 py-3 text-sm font-semibold text-primary-foreground shadow-[0_15px_40px_-10px_var(--primary)]"
        >
          {t("Browse Menu", "تصفح القائمة")}
        </Link>
      </div>
    );
  }

  const valid = address && phone;

  return (
    <div className="mx-auto max-w-3xl px-6 py-12 md:py-16">
      <h1 className="font-display text-4xl font-bold md:text-5xl">
        🛒 {t("Complete Your Order", "أكمل طلبك")}
      </h1>
      <p className="mt-2 text-muted-foreground">
        {t("Almost there — just a few details.", "خطوة كمان وبس.")}
      </p>

      {/* Items */}
      <motion.div
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
        className="mt-8 rounded-3xl border border-border bg-card/40 p-6"
      >
        <div className="mb-4 text-xs font-semibold uppercase tracking-[0.3em] text-muted-foreground">
          {t("Order Items", "العناصر")}
        </div>
        <div className="space-y-3">
          {cart.map((i) => (
            <div key={i.id} className="flex items-center gap-3 border-b border-border pb-3 last:border-0 last:pb-0">
              <img src={i.img} alt={i.name} className="h-12 w-12 rounded-xl object-cover" />
              <div className="flex-1 text-sm">
                <div className="font-semibold">{lang === "ar" ? i.name_ar : i.name}</div>
                <div className="text-xs text-muted-foreground">×{i.qty}</div>
              </div>
              <div className="font-bold text-primary">{i.price * i.qty} EGP</div>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Delivery */}
      <motion.div
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}
        className="mt-6 rounded-3xl border border-border bg-card/40 p-6"
      >
        <div className="mb-4 text-xs font-semibold uppercase tracking-[0.3em] text-muted-foreground">
          {t("Delivery Details", "تفاصيل التوصيل")}
        </div>
        <label className="mb-1.5 block text-sm font-medium">
          <MapPin className="mr-1.5 inline h-4 w-4 text-primary" /> {t("Address", "العنوان")}
        </label>
        <input
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          placeholder={t("Building, street, area…", "العمارة، الشارع، المنطقة…")}
          className="mb-4 w-full rounded-xl border border-input bg-background/50 px-4 py-3 text-sm outline-none transition focus:border-primary"
        />
        <label className="mb-1.5 block text-sm font-medium">
          <Phone className="mr-1.5 inline h-4 w-4 text-primary" /> {t("Phone", "الهاتف")}
        </label>
        <input
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          placeholder="010xxxxxxxx"
          className="w-full rounded-xl border border-input bg-background/50 px-4 py-3 text-sm outline-none transition focus:border-primary"
        />
        {address && (
          <motion.div
            initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
            className="mt-4 flex items-center justify-between rounded-xl border border-primary/30 bg-primary/10 px-4 py-3 text-sm"
          >
            <span>📦 {lang === "ar" ? area.name_ar : area.name}</span>
            <span className="font-semibold text-gold">+{area.fee} EGP · ⏱ {area.eta} min</span>
          </motion.div>
        )}
      </motion.div>

      {/* Payment */}
      <motion.div
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
        className="mt-6 rounded-3xl border border-border bg-card/40 p-6"
      >
        <div className="mb-4 text-xs font-semibold uppercase tracking-[0.3em] text-muted-foreground">
          {t("Payment Method", "طريقة الدفع")}
        </div>
        <div className="grid grid-cols-2 gap-3">
          {PAYMENTS.map((p) => {
            const Icon = p.icon;
            const active = payment === p.id;
            return (
              <button
                key={p.id}
                onClick={() => setPayment(p.id)}
                className={`flex flex-col items-center gap-2 rounded-2xl border p-4 transition ${
                  active
                    ? "border-primary bg-primary/15 text-foreground"
                    : "border-border bg-card/40 text-muted-foreground hover:border-muted-foreground"
                }`}
              >
                <Icon className={`h-6 w-6 ${active ? "text-primary" : ""}`} />
                <span className="text-xs font-semibold">{lang === "ar" ? p.labelAr : p.labelEn}</span>
              </button>
            );
          })}
        </div>
      </motion.div>

      {/* Total */}
      <motion.div
        initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}
        className="mt-6 rounded-3xl border border-border bg-card/40 p-6"
      >
        <div className="flex justify-between py-1 text-sm text-muted-foreground">
          <span>{t("Subtotal", "المجموع")}</span><span>{subtotal} EGP</span>
        </div>
        <div className="flex justify-between py-1 text-sm text-muted-foreground">
          <span>🚚 {t("Delivery", "توصيل")}</span><span>{area.fee} EGP</span>
        </div>
        <div className="mt-3 flex items-end justify-between border-t border-border pt-4">
          <span className="text-sm font-medium">{t("Total", "الإجمالي")}</span>
          <span className="font-display text-3xl font-bold text-gradient-primary">
            {total} <span className="text-sm">EGP</span>
          </span>
        </div>
      </motion.div>

      {/* Actions */}
      <div className="mt-6 grid gap-3">
        {payment === "whatsapp" ? (
          <button
            onClick={handleWhatsapp}
            disabled={!valid}
            className="shine rounded-full bg-gradient-to-r from-jade to-[oklch(0.55_0.15_155)] px-6 py-4 font-semibold text-background shadow-[0_15px_40px_-10px_oklch(0.6_0.15_155)] transition disabled:opacity-50"
          >
            💬 {t("Send Order via WhatsApp", "أرسل عبر واتساب")}
          </button>
        ) : (
          <button
            onClick={handlePlace}
            disabled={!valid}
            className="shine rounded-full bg-gradient-to-r from-primary to-primary-glow px-6 py-4 font-semibold text-primary-foreground shadow-[0_15px_40px_-10px_var(--primary)] transition disabled:cursor-not-allowed disabled:opacity-40"
          >
            🍣 {t("Place Order", "تأكيد الطلب")}
          </button>
        )}
        <a
          href="tel:01007726633"
          className="rounded-full border border-border bg-card/40 px-6 py-3 text-center text-sm font-semibold text-foreground"
        >
          📞 {t("Call Now: 01007726633", "اتصل الآن: ٠١٠٠٧٧٢٦٦٣٣")}
        </a>
      </div>
    </div>
  );
}
