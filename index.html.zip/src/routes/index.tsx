import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowRight, Star, Phone, MapPin, Clock, Sparkles } from "lucide-react";
import { ParticlesBg } from "@/components/sushi/ParticlesBg";
import { SushiCard } from "@/components/sushi/SushiCard";
import { ReviewCard } from "@/components/sushi/ReviewCard";
import { MENU, REVIEWS, PHOTOS } from "@/data/sushi";
import { useSushi } from "@/store/sushi-store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Sushi Circle — Bold Japanese Sushi · Madinaty & New Cairo" },
      { name: "description", content: "The sauce that changed everything. Premium sushi, fast delivery across Madinaty, New Cairo, Nasr City. Order online or visit Central Park." },
      { property: "og:title", content: "Sushi Circle — The Sauce That Changed Everything 🔥" },
      { property: "og:description", content: "Premium sushi, fresh daily, delivered hot. Madinaty Central Park · New Cairo." },
      { property: "og:image", content: PHOTOS.hero },
      { name: "twitter:image", content: PHOTOS.hero },
    ],
  }),
  component: HomePage,
});

const VIRAL_QUOTES = [
  "الصوص ده غير حياتي 😭🔥",
  "أحسن سوشي في القاهرة",
  "Dragon Roll = addiction 🐉",
  "أسرع ديليفري في مدينتي 🛵",
  "Worth every penny ✨",
  "القعدة في السنترال بارك 🌿",
];

function HomePage() {
  const { t, lang } = useSushi();
  const featured = MENU.slice(0, 4);

  return (
    <div className="relative">
      {/* ─── HERO ─────────────────────────────────────────── */}
      <section className="relative -mt-[72px] flex min-h-[100svh] items-center justify-center overflow-hidden pt-[72px]">
        <div className="absolute inset-0">
          <img
            src={PHOTOS.hero}
            alt="Premium sushi platter"
            className="h-full w-full object-cover object-[center_40%]"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background/40 via-background/70 to-background" />
          <div className="absolute inset-0" style={{ background: "var(--gradient-radial-glow)" }} />
        </div>
        <ParticlesBg density={90} />

        {/* floating sushi accents */}
        <motion.div
          aria-hidden
          className="pointer-events-none absolute left-[8%] top-[18%] hidden text-6xl opacity-40 md:block"
          animate={{ y: [0, -20, 0], rotate: [0, 8, 0] }}
          transition={{ duration: 6, repeat: Infinity }}
        >
          🍣
        </motion.div>
        <motion.div
          aria-hidden
          className="pointer-events-none absolute right-[10%] top-[28%] hidden text-5xl opacity-40 md:block"
          animate={{ y: [0, 20, 0], rotate: [0, -10, 0] }}
          transition={{ duration: 7, repeat: Infinity }}
        >
          🥢
        </motion.div>
        <motion.div
          aria-hidden
          className="pointer-events-none absolute bottom-[15%] left-[14%] hidden text-4xl opacity-30 md:block"
          animate={{ y: [0, -15, 0] }}
          transition={{ duration: 5, repeat: Infinity }}
        >
          🌸
        </motion.div>

        <div className="relative z-10 mx-auto max-w-5xl px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-4 py-1.5 text-[11px] font-semibold uppercase tracking-[0.3em] text-primary backdrop-blur"
          >
            <Sparkles className="h-3 w-3" />
            {t("Madinaty Central Park · New Cairo", "سنترال بارك مدينتي · القاهرة الجديدة")}
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="font-display text-[clamp(3rem,11vw,8rem)] font-black leading-[0.9] tracking-tighter"
          >
            <span className="block">SUSHI</span>
            <span className="block text-gradient-primary">CIRCLE</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="font-jp mx-auto mt-4 max-w-xl text-base text-muted-foreground md:text-lg"
          >
            {t(
              "The sauce that changed everything. Bold, fresh, unforgettable.",
              "الصوص اللي غير اللعبة. جريء، طازج، لا يُنسى.",
            )}
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="mt-8 flex flex-wrap items-center justify-center gap-3"
          >
            <Link
              to="/menu"
              className="shine group flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-primary-glow px-7 py-3.5 text-sm font-semibold text-primary-foreground shadow-[0_15px_40px_-10px_var(--primary)] transition hover:brightness-110"
            >
              {t("Explore Menu", "تصفح القائمة")}
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
            <Link
              to="/order"
              className="flex items-center gap-2 rounded-full border border-border bg-card/40 px-7 py-3.5 text-sm font-semibold text-foreground backdrop-blur transition hover:bg-card"
            >
              {t("Order Now", "اطلب الآن")} 🛵
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.9 }}
            className="mt-8 flex flex-wrap items-center justify-center gap-3 text-xs"
          >
            <span className="flex items-center gap-1.5 rounded-full border border-jade/40 bg-jade/10 px-3 py-1 font-medium text-jade">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-jade opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-jade" />
              </span>
              {t("Open · Closes 12 AM", "مفتوح · يغلق ١٢ منتصف الليل")}
            </span>
            <span className="flex items-center gap-1.5 rounded-full border border-gold/40 bg-gold/10 px-3 py-1 font-medium text-gold">
              <Star className="h-3 w-3 fill-current" /> 4.9 · 280+ {t("reviews", "تقييم")}
            </span>
            <a
              href="tel:01007726633"
              className="flex items-center gap-1.5 rounded-full border border-border bg-card/40 px-3 py-1 font-medium text-foreground"
            >
              <Phone className="h-3 w-3" /> 01007726633
            </a>
          </motion.div>
        </div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-muted-foreground">
          <motion.div animate={{ y: [0, 8, 0] }} transition={{ duration: 2, repeat: Infinity }}>
            <div className="h-10 w-6 rounded-full border-2 border-muted-foreground/40 p-1">
              <div className="h-2 w-1 rounded-full bg-primary mx-auto" />
            </div>
          </motion.div>
        </div>
      </section>

      {/* ─── VIRAL MARQUEE ────────────────────────────────── */}
      <section className="overflow-hidden border-y border-border bg-card/30 py-5">
        <div className="flex gap-12 whitespace-nowrap animate-marquee">
          {[...VIRAL_QUOTES, ...VIRAL_QUOTES].map((q, i) => (
            <span key={i} className="font-display text-2xl font-bold tracking-wide">
              <span className="text-gradient-primary">★</span>{" "}
              <span className="text-foreground/80">{q}</span>
            </span>
          ))}
        </div>
      </section>

      {/* ─── STATS ────────────────────────────────────────── */}
      <section className="mx-auto max-w-6xl px-6 py-20 md:py-28">
        <div className="grid gap-6 md:grid-cols-4">
          {[
            { n: "50K+", l: t("Rolls Served", "رول قُدّم") },
            { n: "4.9★", l: t("Avg Rating", "متوسط التقييم") },
            { n: "30 min", l: t("Avg Delivery", "متوسط التوصيل") },
            { n: "100%", l: t("Fresh Daily", "طازج يوميًا") },
          ].map((s, i) => (
            <motion.div
              key={s.l}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="rounded-3xl border border-border bg-card/40 p-6 text-center backdrop-blur"
            >
              <div className="font-display text-4xl font-black text-gradient-primary md:text-5xl">{s.n}</div>
              <div className="mt-1 text-xs uppercase tracking-widest text-muted-foreground">{s.l}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* ─── FEATURED MENU ────────────────────────────────── */}
      <section className="mx-auto max-w-7xl px-6 py-16 md:py-24">
        <div className="mb-12 flex flex-col items-center text-center">
          <span className="text-xs font-semibold uppercase tracking-[0.4em] text-primary">
            {t("Signature Selection", "الاختيار المميز")}
          </span>
          <h2 className="mt-3 font-display text-4xl font-bold md:text-6xl">
            {t("Crafted to ", "أعمال فنية ")}
            <span className="text-gradient-primary">
              {t("Obsess Over", "لتعشقها")}
            </span>
          </h2>
          <p className="mt-4 max-w-xl text-muted-foreground">
            {t(
              "Every piece, hand-rolled by chefs trained in the Edo tradition. Every sauce, mixed in-house.",
              "كل قطعة تُحضّر يدوياً من شيفات على تقاليد إيدو. كل صوص يُحضّر داخل مطبخنا.",
            )}
          </p>
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {featured.map((item, i) => (
            <SushiCard key={item.id} item={item} index={i} />
          ))}
        </div>

        <div className="mt-12 text-center">
          <Link
            to="/menu"
            className="inline-flex items-center gap-2 rounded-full border border-border px-7 py-3 text-sm font-semibold transition hover:border-primary hover:text-primary"
          >
            {t("View Full Menu", "القائمة كاملة")} <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* ─── EXPERIENCE / 3D PARALLAX ─────────────────────── */}
      <section className="relative overflow-hidden py-24">
        <div className="mx-auto grid max-w-7xl gap-10 px-6 md:grid-cols-2 md:items-center">
          <div className="perspective-1000 relative h-[500px]">
            <motion.img
              src={PHOTOS.platter}
              alt="Sushi platter"
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7 }}
              className="absolute left-0 top-0 h-72 w-72 rounded-3xl object-cover shadow-elevated [transform:rotateY(-8deg)_rotateX(4deg)]"
            />
            <motion.img
              src={PHOTOS.chef}
              alt="Chef"
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: 0.15 }}
              className="absolute right-0 top-20 h-64 w-52 rounded-3xl object-cover shadow-elevated [transform:rotateY(8deg)_rotateX(-2deg)]"
            />
            <motion.img
              src={PHOTOS.ambience}
              alt="Restaurant ambience"
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.7, delay: 0.3 }}
              className="absolute bottom-0 left-12 h-56 w-80 rounded-3xl object-cover shadow-elevated [transform:rotateY(-4deg)_rotateX(-4deg)]"
            />
          </div>

          <div>
            <span className="text-xs font-semibold uppercase tracking-[0.4em] text-primary">
              {t("The Experience", "التجربة")}
            </span>
            <h2 className="mt-3 font-display text-4xl font-bold md:text-5xl">
              {t("Where ", "حيث ")}
              <span className="text-gradient-gold">{t("Cairo Meets Tokyo", "تلتقي القاهرة بطوكيو")}</span>
            </h2>
            <p className="mt-5 text-muted-foreground">
              {t(
                "Step into our Central Park space. Warm wood, soft lanterns, the soundtrack of a sizzling robata. Whether you're dining in, picking up at the drive-thru, or unboxing at home — every detail is designed to make you stay.",
                "ادخل عالمنا في السنترال بارك. خشب دافئ، فوانيس هادئة، وأصوات الروباتا. سواء كنت معنا أو تأخذ طلبك أو تفتحه في البيت، كل تفصيلة مصممة عشان تخليك تقعد.",
              )}
            </p>
            <div className="mt-8 grid grid-cols-2 gap-4">
              {[
                ["🍽", t("Dine-in", "في المطعم")],
                ["🚗", t("Drive-thru", "درايف ثرو")],
                ["🛵", t("Delivery", "توصيل")],
                ["🤝", t("Contactless", "بدون لمس")],
              ].map(([i, l]) => (
                <div key={l} className="flex items-center gap-3 rounded-2xl border border-border bg-card/40 p-4">
                  <span className="text-2xl">{i}</span>
                  <span className="text-sm font-medium">{l}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ─── REVIEWS ──────────────────────────────────────── */}
      <section className="border-y border-border bg-card/20 py-20">
        <div className="mx-auto max-w-7xl">
          <div className="mb-10 px-6 text-center">
            <span className="text-xs font-semibold uppercase tracking-[0.4em] text-primary">
              {t("People Are Talking", "الناس بتتكلم")}
            </span>
            <h2 className="mt-3 font-display text-4xl font-bold md:text-5xl">
              {t("Real ", "تقييمات ")}
              <span className="text-gradient-primary">{t("Reviews ❤️", "حقيقية ❤️")}</span>
            </h2>
          </div>
          <div className="no-scrollbar flex gap-5 overflow-x-auto px-6 pb-4">
            {REVIEWS.map((r) => (
              <ReviewCard key={r.id} r={r} />
            ))}
          </div>
        </div>
      </section>

      {/* ─── CTA ──────────────────────────────────────────── */}
      <section className="relative overflow-hidden py-24">
        <div className="absolute inset-0">
          <img src={PHOTOS.heroAlt} alt="" className="h-full w-full object-cover opacity-25" />
          <div className="absolute inset-0 bg-gradient-to-b from-background via-background/80 to-background" />
        </div>
        <div className="relative mx-auto max-w-3xl px-6 text-center">
          <h2 className="font-display text-4xl font-bold md:text-6xl">
            {t("Ready to taste ", "مستعد تجرب ")}
            <span className="text-gradient-primary">{t("the obsession?", "الإدمان؟")}</span>
          </h2>
          <p className="mt-4 text-muted-foreground">
            {t(
              "Order in 30 seconds. Hot at your door in 30 minutes.",
              "اطلب في ٣٠ ثانية. هيوصلك ساخن في ٣٠ دقيقة.",
            )}
          </p>
          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <Link
              to="/order"
              className="shine flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-primary-glow px-8 py-4 font-semibold text-primary-foreground shadow-[0_20px_50px_-15px_var(--primary)]"
            >
              {t("Order Now", "اطلب الآن")} <ArrowRight className="h-4 w-4" />
            </Link>
            <a
              href="https://wa.me/201007726633"
              className="flex items-center gap-2 rounded-full border border-border bg-card/60 px-8 py-4 font-semibold backdrop-blur"
            >
              💬 WhatsApp
            </a>
          </div>
          <div className="mt-10 flex flex-wrap justify-center gap-6 text-sm text-muted-foreground">
            <span className="flex items-center gap-2"><MapPin className="h-4 w-4 text-primary" /> Madinaty Central Park</span>
            <span className="flex items-center gap-2"><Clock className="h-4 w-4 text-primary" /> 12 PM – 12 AM</span>
            <span className="flex items-center gap-2"><Phone className="h-4 w-4 text-primary" /> 01007726633</span>
          </div>
        </div>
      </section>
    </div>
  );
}
