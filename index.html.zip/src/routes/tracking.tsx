import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Phone, Check } from "lucide-react";
import { useSushi } from "@/store/sushi-store";
import { STATUSES, STATUS_COLORS, PHOTOS } from "@/data/sushi";

export const Route = createFileRoute("/tracking")({
  head: () => ({
    meta: [
      { title: "Track Order — Sushi Circle" },
      { name: "description", content: "Track your Sushi Circle order in real time. See chef status, driver, and ETA." },
    ],
  }),
  component: TrackingPage,
});

function TrackingPage() {
  const { orderPlaced, t } = useSushi();

  if (!orderPlaced) {
    return (
      <div className="mx-auto flex min-h-[70vh] max-w-md flex-col items-center justify-center px-6 text-center">
        <img src={PHOTOS.platter} alt="" className="mb-6 h-40 w-56 rounded-3xl object-cover opacity-60" />
        <h2 className="font-display text-3xl font-bold">{t("No active order", "لا يوجد طلب نشط")}</h2>
        <p className="mt-2 text-muted-foreground">{t("Hungry yet?", "جوعت؟")}</p>
        <Link
          to="/menu"
          className="mt-6 rounded-full bg-gradient-to-r from-primary to-primary-glow px-8 py-3 text-sm font-semibold text-primary-foreground"
        >
          {t("Start Ordering", "ابدأ الطلب")}
        </Link>
      </div>
    );
  }

  const statusIdx = STATUSES.indexOf(orderPlaced.status);
  const icon = orderPlaced.status === "Delivered" ? "✅" : orderPlaced.status === "Out for Delivery" ? "🛵" : "👨‍🍳";

  return (
    <div className="mx-auto max-w-2xl px-6 py-12 md:py-16">
      <div className="text-center">
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: "spring", stiffness: 200, damping: 15 }}
          className="mx-auto mb-4 grid h-24 w-24 place-items-center rounded-full text-5xl"
          style={{
            background: `radial-gradient(circle, ${STATUS_COLORS[orderPlaced.status]}40, transparent)`,
            filter: `drop-shadow(0 0 30px ${STATUS_COLORS[orderPlaced.status]})`,
          }}
        >
          {icon}
        </motion.div>
        <h1 className="font-display text-3xl font-bold md:text-4xl">
          {t("Order #", "طلب رقم #")}{String(orderPlaced.id).slice(-4)}
        </h1>
        <div
          className="mt-2 inline-block rounded-full px-4 py-1 text-sm font-semibold"
          style={{ color: STATUS_COLORS[orderPlaced.status], background: `${STATUS_COLORS[orderPlaced.status]}20` }}
        >
          {orderPlaced.status}
        </div>
      </div>

      {/* Stepper */}
      <div className="mt-10 rounded-3xl border border-border bg-card/40 p-6">
        <div className="relative flex items-start justify-between">
          <div className="absolute left-6 right-6 top-5 h-0.5 bg-border" />
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${(statusIdx / (STATUSES.length - 1)) * 100}%` }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="absolute left-6 top-5 h-0.5 bg-gradient-to-r from-primary to-primary-glow"
            style={{ maxWidth: "calc(100% - 48px)" }}
          />
          {STATUSES.map((s, i) => (
            <div key={s} className="relative z-10 flex flex-1 flex-col items-center gap-2">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: i * 0.2, type: "spring" }}
                className={`grid h-10 w-10 place-items-center rounded-full text-sm font-bold transition ${
                  i <= statusIdx
                    ? "bg-gradient-to-br from-primary to-primary-glow text-primary-foreground shadow-[0_0_20px_var(--primary)]"
                    : "border border-border bg-card text-muted-foreground"
                }`}
              >
                {i < statusIdx ? <Check className="h-4 w-4" /> : i + 1}
              </motion.div>
              <span className={`text-center text-[10px] font-semibold uppercase tracking-wider ${i <= statusIdx ? "text-foreground" : "text-muted-foreground"}`}>
                {s}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Items */}
      <div className="mt-6 rounded-3xl border border-border bg-card/40 p-6">
        <div className="mb-3 text-xs font-semibold uppercase tracking-[0.3em] text-muted-foreground">
          {t("Your Order", "طلبك")}
        </div>
        <div className="flex flex-wrap gap-3">
          {orderPlaced.items.map((i) => (
            <div key={i.id} className="relative">
              <img src={i.img} alt={i.name} className="h-16 w-16 rounded-2xl object-cover ring-2 ring-border" />
              <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-primary px-1 text-[10px] font-bold text-primary-foreground">
                {i.qty}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Driver */}
      <div className="mt-6 rounded-3xl border border-border bg-card/40 p-6">
        <div className="mb-3 text-xs font-semibold uppercase tracking-[0.3em] text-muted-foreground">
          {t("Your Driver", "السائق")}
        </div>
        <div className="flex items-center gap-4">
          <div className="grid h-12 w-12 place-items-center rounded-full bg-primary/15 text-sm font-bold text-primary ring-2 ring-primary/30">
            {orderPlaced.driver.avatar}
          </div>
          <div className="flex-1">
            <div className="font-semibold">{orderPlaced.driver.name}</div>
            <div className="text-xs text-muted-foreground">📞 {orderPlaced.driver.phone}</div>
          </div>
          <a
            href={`tel:${orderPlaced.driver.phone}`}
            className="flex items-center gap-1.5 rounded-full bg-jade/15 px-4 py-2 text-xs font-semibold text-jade ring-1 ring-jade/30"
          >
            <Phone className="h-3.5 w-3.5" /> {t("Call", "اتصل")}
          </a>
        </div>
      </div>

      {/* Summary */}
      <div className="mt-6 grid grid-cols-3 gap-3">
        {[
          ["📍", t("Area", "المنطقة"), orderPlaced.area],
          ["⏱", t("ETA", "الوقت"), `${orderPlaced.eta} min`],
          ["💰", t("Total", "الإجمالي"), `${orderPlaced.total} EGP`],
        ].map(([ic, lb, vl]) => (
          <div key={lb as string} className="rounded-2xl border border-border bg-card/40 p-4 text-center">
            <div className="text-2xl">{ic}</div>
            <div className="mt-1 text-[10px] uppercase tracking-widest text-muted-foreground">{lb}</div>
            <div className="mt-1 text-sm font-semibold">{vl}</div>
          </div>
        ))}
      </div>

      <Link
        to="/menu"
        className="mt-6 block w-full rounded-full border border-border bg-card/40 py-3 text-center text-sm font-semibold transition hover:border-primary hover:text-primary"
      >
        🍣 {t("Order Again", "اطلب مرة أخرى")}
      </Link>
    </div>
  );
}
