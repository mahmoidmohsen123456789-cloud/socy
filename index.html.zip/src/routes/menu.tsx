import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import { SushiCard } from "@/components/sushi/SushiCard";
import { MENU, PHOTOS } from "@/data/sushi";
import { useSushi } from "@/store/sushi-store";

export const Route = createFileRoute("/menu")({
  head: () => ({
    meta: [
      { title: "Menu — Sushi Circle · Premium Rolls, Nigiri & Sashimi" },
      { name: "description", content: "Browse the full Sushi Circle menu: signature rolls, nigiri, sashimi, Wagyu, lobster and more. Order delivery in Madinaty & New Cairo." },
      { property: "og:title", content: "Sushi Circle Menu — Signature Rolls & Sashimi" },
      { property: "og:description", content: "Hand-rolled by Edo-trained chefs. Fresh daily. Order online." },
      { property: "og:image", content: PHOTOS.platter },
      { name: "twitter:image", content: PHOTOS.platter },
    ],
  }),
  component: MenuPage,
});

const CATS = [
  { id: "all", labelEn: "All", labelAr: "الكل", emoji: "🍱" },
  { id: "signature", labelEn: "Signature", labelAr: "المميز", emoji: "⭐" },
  { id: "rolls", labelEn: "Rolls", labelAr: "رول", emoji: "🍣" },
  { id: "nigiri", labelEn: "Nigiri", labelAr: "نيجيري", emoji: "🍙" },
  { id: "sashimi", labelEn: "Sashimi", labelAr: "ساشيمي", emoji: "🐟" },
] as const;

function MenuPage() {
  const { t, lang } = useSushi();
  const [cat, setCat] = useState<string>("all");

  const items = cat === "all" ? MENU : MENU.filter((m) => m.category === cat);

  return (
    <div className="relative">
      {/* Header band */}
      <div className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0 opacity-30">
          <img src={PHOTOS.platter} alt="" className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/85 to-background" />
        </div>
        <div className="relative mx-auto max-w-7xl px-6 py-20 text-center md:py-28">
          <span className="text-xs font-semibold uppercase tracking-[0.4em] text-primary">
            {t("Our Menu", "قائمتنا")}
          </span>
          <h1 className="mt-3 font-display text-5xl font-bold md:text-7xl">
            {t("The ", "")}
            <span className="text-gradient-gold">{t("Whole Circle", "القائمة الكاملة")}</span>
          </h1>
          <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
            {t(
              "Eight signature creations. Endless obsession.",
              "ثماني إبداعات مميزة. إدمان لا ينتهي.",
            )}
          </p>
        </div>
      </div>

      {/* Sticky filter */}
      <div className="sticky top-[72px] z-20 border-b border-border glass-strong">
        <div className="no-scrollbar mx-auto flex max-w-7xl gap-2 overflow-x-auto px-6 py-4">
          {CATS.map((c) => {
            const active = cat === c.id;
            return (
              <button
                key={c.id}
                onClick={() => setCat(c.id)}
                className={`relative flex shrink-0 items-center gap-2 rounded-full px-5 py-2 text-sm font-semibold transition ${
                  active
                    ? "bg-gradient-to-r from-primary to-primary-glow text-primary-foreground shadow-[0_8px_25px_-8px_var(--primary)]"
                    : "border border-border bg-card/40 text-muted-foreground hover:text-foreground"
                }`}
              >
                <span>{c.emoji}</span>
                {lang === "ar" ? c.labelAr : c.labelEn}
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid */}
      <section className="mx-auto max-w-7xl px-6 py-16">
        <motion.div
          layout
          className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
        >
          {items.map((item, i) => (
            <SushiCard key={item.id} item={item} index={i} />
          ))}
        </motion.div>
      </section>
    </div>
  );
}
