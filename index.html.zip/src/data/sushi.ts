export const PHOTOS = {
  hero: "https://images.unsplash.com/photo-1579871494447-9811cf80d66c?w=1600&q=85",
  heroAlt: "https://images.unsplash.com/photo-1553621042-f6e147245754?w=1600&q=85",
  platter: "https://images.unsplash.com/photo-1617196034183-421b4040ed20?w=1000&q=85",
  salmon: "https://images.unsplash.com/photo-1534482421-64566f976cfa?w=800&q=85",
  roll1: "https://images.unsplash.com/photo-1562802378-063ec186a863?w=800&q=85",
  roll2: "https://images.unsplash.com/photo-1559410545-0bdcd187e0a6?w=800&q=85",
  nigiri: "https://images.unsplash.com/photo-1611143669185-af224c5e3252?w=800&q=85",
  sauce: "https://images.unsplash.com/photo-1633525466342-c30a4f62e23c?w=800&q=85",
  ambience: "https://images.unsplash.com/photo-1514190051997-0f6f39ca5cde?w=1200&q=85",
  chef: "https://images.unsplash.com/photo-1607631568010-a87245c0daf8?w=800&q=85",
  rainbow: "https://images.unsplash.com/photo-1607301405390-d831c242f59b?w=800&q=85",
  wagyu: "https://images.unsplash.com/photo-1606270842810-8efbb33dab28?w=800&q=85",
  lobster: "https://images.unsplash.com/photo-1648147672152-de8b3afa6f74?w=800&q=85",
  volcano: "https://images.unsplash.com/photo-1607247098560-1a4d3f1f8d6f?w=800&q=85",
  black: "https://images.unsplash.com/photo-1615361200141-f45040f367be?w=800&q=85",
};

export type MenuItem = {
  id: number;
  name: string;
  name_ar: string;
  price: number;
  desc: string;
  desc_ar: string;
  emoji: string;
  color: string;
  sauces: string[];
  hot: boolean;
  img: string;
  category: "signature" | "rolls" | "nigiri" | "sashimi";
};

export const MENU: MenuItem[] = [
  { id: 1, name: "Dragon Roll", name_ar: "درول دراجون", price: 189, desc: "Shrimp tempura, avocado, unagi sauce", desc_ar: "جمبري تيمبورا، أفوكادو، صوص أوناجي", emoji: "🐉", color: "oklch(0.58 0.22 25)", sauces: ["Unagi", "Sriracha Mayo"], hot: true, img: PHOTOS.roll1, category: "signature" },
  { id: 2, name: "Salmon Sashimi", name_ar: "سلمون ساشيمي", price: 145, desc: "Premium fresh salmon slices, ponzu", desc_ar: "شرائح سلمون طازجة فاخرة، بونزو", emoji: "🐟", color: "oklch(0.7 0.18 45)", sauces: ["Ponzu", "Soy Ginger"], hot: false, img: PHOTOS.salmon, category: "sashimi" },
  { id: 3, name: "Spicy Tuna Roll", name_ar: "رول تونة حار", price: 155, desc: "Spicy tuna, cucumber, sesame crust", desc_ar: "تونة حارة، خيار، طبقة سمسم", emoji: "🌶️", color: "oklch(0.62 0.22 30)", sauces: ["Spicy Mayo", "Sriracha"], hot: true, img: PHOTOS.roll2, category: "rolls" },
  { id: 4, name: "Rainbow Roll", name_ar: "رول قوس قزح", price: 210, desc: "California roll topped with assorted fish", desc_ar: "كاليفورنيا رول مع تشكيلة أسماك", emoji: "🌈", color: "oklch(0.78 0.14 80)", sauces: ["Eel Sauce", "Wasabi Mayo"], hot: false, img: PHOTOS.rainbow, category: "signature" },
  { id: 5, name: "Wagyu Nigiri", name_ar: "نيجيري واجيو", price: 285, desc: "A5 Wagyu, truffle salt, micro herbs", desc_ar: "واجيو A5، ملح ترافل، أعشاب دقيقة", emoji: "🥩", color: "oklch(0.78 0.14 80)", sauces: ["Truffle Soy", "Yuzu"], hot: true, img: PHOTOS.wagyu, category: "nigiri" },
  { id: 6, name: "Black Tiger Roll", name_ar: "رول النمر الأسود", price: 175, desc: "Crab, cream cheese, black sesame", desc_ar: "كراب، كريم تشيز، سمسم أسود", emoji: "⚫", color: "oklch(0.5 0.05 250)", sauces: ["Black Sesame", "Spicy Aioli"], hot: false, img: PHOTOS.black, category: "rolls" },
  { id: 7, name: "Lobster Roll", name_ar: "رول لوبستر", price: 320, desc: "Fresh lobster, mango, passion fruit sauce", desc_ar: "لوبستر طازج، مانجو، صوص باشن فروت", emoji: "🦞", color: "oklch(0.65 0.22 25)", sauces: ["Passion Fruit", "Citrus Mayo"], hot: true, img: PHOTOS.lobster, category: "signature" },
  { id: 8, name: "Volcano Roll", name_ar: "رول بركان", price: 195, desc: "Baked scallop, spicy mix, roe topping", desc_ar: "اسكالوب مشوي، خلطة حارة، بطارخ", emoji: "🌋", color: "oklch(0.65 0.2 40)", sauces: ["Volcano", "Sriracha Honey"], hot: true, img: PHOTOS.volcano, category: "signature" },
];

export const REVIEWS = [
  { id: 1, name: "Nour M.", avatar: "NM", stars: 5, time: "2 days ago", text: "الصوص ده غير حياتي والله 😭🔥 أحسن سوشي في القاهرة الجديدة بدون نقاش!", en: "This sauce changed my life 😭🔥 Best sushi in New Cairo, no debate!", likes: 247 },
  { id: 2, name: "Ahmed K.", avatar: "AK", stars: 5, time: "1 week ago", text: "الأكل نظيف والسعر مش مبالغ فيه خالص، الصوص تحفة وكتير جداً 🥢", en: "Clean food, fair price, the sauce is amazing and so varied 🥢", likes: 131 },
  { id: 3, name: "Sara T.", avatar: "ST", stars: 5, time: "3 days ago", text: "القعدة تحفة في السنترال بارك، الجو حلو والأكل أحلى 🌿✨", en: "Sitting at Central Park is stunning, vibe + food = perfect ✨", likes: 98 },
  { id: 4, name: "Omar F.", avatar: "OF", stars: 5, time: "5 days ago", text: "Dragon Roll ده addiction والله مش هينفع تاكل بره تاني 🍣🔥", en: "Dragon Roll is an addiction, you can't eat anywhere else after this 🔥", likes: 362 },
  { id: 5, name: "Layla H.", avatar: "LH", stars: 5, time: "1 day ago", text: "أسرع ديليفري في مدينتي، وصل ساخن وطازج ومعاه صوص زيادة 😍", en: "Fastest delivery in Madinaty, arrived hot + fresh + extra sauce 😍", likes: 139 },
  { id: 6, name: "Youssef A.", avatar: "YA", stars: 5, time: "4 days ago", text: "Wagyu Nigiri تجربة من تاني عالم 🤯 يستاهل كل قرش", en: "Wagyu Nigiri is from another world 🤯 worth every penny", likes: 87 },
];

export const AREAS = [
  { name: "Madinaty", name_ar: "مدينتي", fee: 30, eta: 30, keywords: ["madinaty", "مدينتي"] },
  { name: "New Cairo", name_ar: "القاهرة الجديدة", fee: 40, eta: 40, keywords: ["new cairo", "cairo", "القاهرة", "التجمع", "rehab", "رحاب", "shorouk", "الشروق"] },
  { name: "Nasr City", name_ar: "مدينة نصر", fee: 50, eta: 50, keywords: ["nasr", "نصر", "مدينة نصر"] },
  { name: "Other Area", name_ar: "منطقة أخرى", fee: 60, eta: 60, keywords: [] },
];

export const DRIVERS = [
  { name: "Ahmed Hassan", phone: "01012345678", avatar: "AH" },
  { name: "Mohamed Ali", phone: "01098765432", avatar: "MA" },
  { name: "Karim Samir", phone: "01155443322", avatar: "KS" },
];

export const STATUSES = ["Preparing", "Out for Delivery", "Delivered"] as const;
export type OrderStatus = typeof STATUSES[number];

export const STATUS_COLORS: Record<OrderStatus, string> = {
  "Preparing": "oklch(0.78 0.14 80)",
  "Out for Delivery": "oklch(0.72 0.13 220)",
  "Delivered": "oklch(0.72 0.15 155)",
};
